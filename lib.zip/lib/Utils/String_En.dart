class StringEn {
  static const FEED = "Feed";
  static const CREATE_POST = "Create Post";
// static const LOGOUT_TEXT = "Do you really want to logout this app?";
  static const PHOTOS = "Photos/Video";
  static const TYPE_POST = "Write Something here...";
  static const POST = "POST";
  static const CAMERA = "Camera";
  static const GALLERY = "Gallery";
  static const FORWARD = "Forward";
  static const SHARE = "Share";
  static const DELETE = "Delete";
}
